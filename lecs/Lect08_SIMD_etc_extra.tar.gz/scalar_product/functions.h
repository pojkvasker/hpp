#include <pmmintrin.h>   /* SSE3 */
#include <immintrin.h>   /* AVX, FMA */

float scalarproduct(float * array1, float * array2, size_t length);
float scalarproduct_aligned(float * array1, float * array2, size_t length);
float sse_scalarproduct(float * array1, float * array2, size_t length);
float avx_scalarproduct(float * array1, float * array2, size_t length);
float avx_scalarproduct_aligned(float * array1, float * array2, size_t length);
