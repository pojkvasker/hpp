int f(int k);

// The gcc syntax for declaring f as a pure function is as follows:
//int f(int k) __attribute__((const));

int get_counter();
