#include<stdio.h>
#include<float.h>

int main(){
    printf("Real precision        = %e\n", FLT_EPSILON);
    printf("Double precision      = %e\n", DBL_EPSILON);
}
