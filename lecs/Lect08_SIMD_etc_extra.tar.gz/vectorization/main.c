#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include  <math.h>
#include "function.h"


static double get_wall_seconds() {
        struct timeval tv;
        gettimeofday(&tv, NULL);
        double seconds = tv.tv_sec + (double)tv.tv_usec / 1000000;
        return seconds;
}


int main()
{
        const int N = 160000;  // LET N % 8 will be 0
        MyType src1[N];
        MyType src2[N];
        MyType dst1[N];
        MyType  sum1 = 0;
        /* Initialize src1 and src2 vectors with some random numbers. */
        int i;
        for(i = 0; i < N; i++)
        {
                src1[i] = (double) rand() / RAND_MAX;
                src2[i] = (double) rand() / RAND_MAX;
        }

        const int nRepetitions = 15000;

        printf("Call function %d times...\n", nRepetitions);

        double time1 = get_wall_seconds();
        for(i = 0; i < nRepetitions; i++)
                sum_arrays(src1, src2, dst1, N);
        printf("Vector sum took %7.3f wall seconds.\n", get_wall_seconds()-time1);



        for(i = 0; i < N; i++)
                sum1 += dst1[i];

        for(i = 0; i < N; i++)
                src1[i] = sin(dst1[i]);

        printf("sum1 = %lf\n", (double) sum1);

/* MATRIX MULTIPLICATION */
#if 0
        int n = 100;
        printf("\nMultiply Matrices of size %d-by-%d\n", n,n);
        MyType *A = (MyType *)malloc(n*n*sizeof(MyType));
        MyType *B = (MyType *)malloc(n*n*sizeof(MyType));
        MyType *C = (MyType *)calloc(n*n,sizeof(MyType));
        fill_matrix(A, n);
        fill_matrix(B, n);
        mult_kij(A, B, C, n);
        free(A);
        free(B);
        free(C);
#endif


/* STRING OPERATIONS */
#if 0
        int numiters = 10000000;
        char string1[100], string2[100];
        for(int i=0; i<99; i++)
        {
                string1[i] = 'A';
                string2[i] = 'A';
        }
        /* null-terminate the string */
        string1[99] = '\0';  string2[99] = '\0';

        for(int i=0; i<numiters; i++)
        {
                lowercase1(string1);
                lowercase2(string2);
        }
#endif


        return 0;
}
