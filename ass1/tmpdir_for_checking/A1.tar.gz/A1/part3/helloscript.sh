echo 'Hej hej'
echo 'Monica'
echo 'Hej på dig Månica'