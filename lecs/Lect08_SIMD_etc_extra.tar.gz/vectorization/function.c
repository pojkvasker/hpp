#include "function.h"
#include <stdio.h>

void sum_arrays(MyType *  a, MyType *   b, MyType *  c, int N) {
        for (size_t i=0; i<N; i++) {
                c[i] = a[i] + b[i];

        }
}


/* MATRIX MULTIPLICATION */
#if 0

void fill_matrix(MyType *A, int N){
        int i,j;
        srand(time(NULL));
        for (i=0; i<N; i++)
                for (j=0; j<N; j++)
                        A[i*N + j] = (MyType)rand()/RAND_MAX*20-10;
}

void mult_kij(MyType * restrict A, MyType * restrict B, MyType * restrict C, int n){
        int k,i,j;
        for(k = 0; k < n; k++) {
                for(i = 0; i < n; i++) {
                        for(j = 0; j < n; j++) {
                                C[i*n+j] = C[i*n+j] + A[i*n+k]*B[k*n+j];
                        }
                }
        }
}

#endif


/* STRING OPERATIONS */
#if 0
void lowercase1(char* p) {
        for (int i = 100; i>0; i--)
                *(p++) |= 0x20;
}


void lowercase2(char* p) {
        while (*p != 0)
                *(p++) |= 0x20;
}
#endif
