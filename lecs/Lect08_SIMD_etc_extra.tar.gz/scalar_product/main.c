/* Inspired by https://lemire.me/blog/2016/12/30/can-your-c-compiler-vectorize-a-scalar-product/ */

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include  <math.h>
#include "functions.h"


static double get_wall_seconds() {
        struct timeval tv;
        gettimeofday(&tv, NULL);
        double seconds = tv.tv_sec + (double)tv.tv_usec / 1000000;
        return seconds;
}


int main()
{
        const int N = 160000;  // LET N % 8 will be 0
        float  src1[N];
        float  src2[N];
        float res_sse = 0, res_avx = 0, res_ref_a = 0, res_ref = 0, res_avx_al = 0;
        float __attribute__((aligned (32))) src1a[N];
        float __attribute__((aligned (32))) src2a[N];
        /* Initialize src1 and src2 vectors with some random numbers. */
        int i;
        for(i = 0; i < N; i++)
        {
                src1[i] = (double) rand() / RAND_MAX-0.5;
                src1a[i] = src1[i];
                src2[i] = (double) rand() / RAND_MAX-0.5;
                src2a[i] = src2[i];
        }

        const int nRepetitions = 15000;


        printf("Call functions %d times...\n", nRepetitions);

        double time1 = get_wall_seconds();
        for(i = 0; i < nRepetitions; i++)
                res_ref = scalarproduct(src1, src2, N);
        printf("Standard scalar product took %7.3f wall seconds.\n", get_wall_seconds()-time1);

        double time2 = get_wall_seconds();
        for(i = 0; i < nRepetitions; i++)
                res_ref_a = scalarproduct_aligned(src1a, src2a, N);
        printf("Standard scalar (aligned) product took %7.3f wall seconds.\n", get_wall_seconds()-time2);

        double time3 = get_wall_seconds();
        for(i = 0; i < nRepetitions; i++)
                res_sse = sse_scalarproduct(src1, src2, N);
        printf("Vector (SSE) scalar product took %7.3f wall seconds.\n", get_wall_seconds()-time3);

        double time4 = get_wall_seconds();
        for(i = 0; i < nRepetitions; i++)
                res_avx = avx_scalarproduct(src1, src2, N);
        printf("Vector (AVX) scalar product took %7.3f wall seconds.\n", get_wall_seconds()-time4);

        double time5 = get_wall_seconds();
        for(i = 0; i < nRepetitions; i++)
                res_avx_al = avx_scalarproduct_aligned(src1a, src2a, N);
        printf("Vector (AVX) scalar product (aligned) took %7.3f wall seconds.\n", get_wall_seconds()-time5);


        printf("%lf\n", res_ref);
        printf("%lf\n", res_ref_a);
        printf("%lf\n", res_sse);
        printf("%lf\n", res_avx);
        printf("%lf\n", res_avx_al);

        return 0;
}
