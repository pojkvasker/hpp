/**
 * Example showing the effect of memory alignment for members in a
 * struct. Based on the mmul_loop_order.c code but using arrays of
 * structs instead of double arrays for the matrices.
 *
 * Look at the difference when adding __attribute((packed)) for
 * valStruct, when compiling with e.g. -O3 -funroll-loops and running
 * for e.g. matrix size 300.
 *
 * Course: High Performance Programming, Uppsala University
 *
 * Author: Elias Rudberg <elias.rudberg@it.uu.se>
 *
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <string.h>

static double get_wall_seconds() {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  double seconds = tv.tv_sec + (double)tv.tv_usec / 1000000;
  return seconds;
}

typedef struct {
  double x;
  // int i;
  // char c0;
  // char c1;
  // char c2;
} valStruct;
//} __attribute((packed)) valStruct;

void fill_matrix(valStruct *A, int N){
  int i,j;
  srand(time(NULL));
  for (i=0; i<N ; i++)
    for (j=0 ; j<N ; j++)
      A[i*N + j].x = (double)rand()/RAND_MAX*20-10;
}

void mult_ijk(valStruct *A,valStruct *B,valStruct *C, int n){
  int k,i,j;
  for(i = 0; i < n; i++) {
    for(j = 0; j < n; j++) {
      for(k = 0; k < n; k++) {
	C[i*n+j].x = C[i*n+j].x + A[i*n+k].x*B[k*n+j].x;
      }
    }
  }
}

void mult_ikj(valStruct *A,valStruct *B,valStruct *C, int n){
  int k,i,j;
  for(i = 0; i < n; i++) {
    for(k = 0; k < n; k++) {
      for(j = 0; j < n; j++) {
	C[i*n+j].x = C[i*n+j].x + A[i*n+k].x*B[k*n+j].x;
      }
    }
  }
}

void mult_jik(valStruct *A,valStruct *B,valStruct *C, int n){
  int k,i,j;
  for(j = 0; j < n; j++) {
    for(i = 0; i < n; i++) {
      for(k = 0; k < n; k++) {
	C[i*n+j].x = C[i*n+j].x + A[i*n+k].x*B[k*n+j].x;
      }
    }
  }
}

void mult_jki(valStruct *A,valStruct *B,valStruct *C, int n){
  int k,i,j;
  for(j = 0; j < n; j++) {
    for(k = 0; k < n; k++) {
      for(i = 0; i < n; i++) {
	C[i*n+j].x = C[i*n+j].x + A[i*n+k].x*B[k*n+j].x;
      }
    }
  }
}

void mult_kij(valStruct *A,valStruct *B,valStruct *C, int n){
  int k,i,j;
  for(k = 0; k < n; k++) {
    for(i = 0; i < n; i++) {
      for(j = 0; j < n; j++) {
	C[i*n+j].x = C[i*n+j].x + A[i*n+k].x*B[k*n+j].x;
      }
    }
  }
}

void mult_kji(valStruct *A,valStruct *B,valStruct *C, int n){
  int k,i,j;
  for(k = 0; k < n; k++) {
    for(j = 0; j < n; j++) {
      for(i = 0; i < n; i++) {
	C[i*n+j].x = C[i*n+j].x + A[i*n+k].x*B[k*n+j].x;
      }
    }
  }
}

/* Use typedef to declare a function pointer type called
   functionPtrType for a function that takes arguments of the types
   (valStruct*, valStruct* ,valStruct*, int). */
typedef void (*functionPtrType)(valStruct*, valStruct* ,valStruct*, int);

void run_tests(functionPtrType f, const char* name, valStruct* A, valStruct* B, valStruct* C, valStruct* Cref, int n) {
  printf("%s:\n", name);
  double t_tot = 0;
  double maxabsdiff = 0;
  int nRepeats = 5;
  int rep, i;
  for(rep = 0; rep < nRepeats; rep++) {
    memset(C, 0, n*n*sizeof(valStruct));
    double t = get_wall_seconds();
    f(A, B, C, n);
    t_tot += get_wall_seconds() - t;
    /* Done. Now compare the result to the given Cref matrix. */
    for(i = 0; i < n*n; i++) {
      double absdiff = fabs(C[i].x-Cref[i].x);
      if(absdiff > maxabsdiff)
	maxabsdiff = absdiff;
    }
  }
  double t_avg = t_tot / nRepeats;
  printf("==> Average time: %9.3f ms  (diff %g)\n", t_avg*1000, maxabsdiff);
}

int main (int argc , char *argv[]){
  int n;
  valStruct *A, *B, *C, *D;

  if(argc != 2){
    printf("The program should have exactly one input argument!\n");
    return 1;
  }
  n = atoi(argv[1]);

  printf("Multiply Matrices of size %d-by-%d. sizeof(valStruct) = %lu\n", n, n, sizeof(valStruct));

  A = (valStruct *)malloc(n*n*sizeof(valStruct));
  B = (valStruct *)malloc(n*n*sizeof(valStruct));
  C = (valStruct *)calloc(n*n,sizeof(valStruct));
  D = (valStruct *)calloc(n*n,sizeof(valStruct));
  fill_matrix(A, n);
  fill_matrix(B, n);

  /* First compute D that will be used as a reference. */
  mult_ijk(A, B, D, n);

  run_tests(mult_ijk, "mult_ijk", A, B, C, D, n);
  run_tests(mult_ikj, "mult_ikj", A, B, C, D, n);
  run_tests(mult_jik, "mult_jik", A, B, C, D, n);
  run_tests(mult_jki, "mult_jki", A, B, C, D, n);
  run_tests(mult_kij, "mult_kij", A, B, C, D, n);
  run_tests(mult_kji, "mult_kji", A, B, C, D, n);

  free(A);
  free(B);
  free(C);
  free(D);
  return 0;
}
