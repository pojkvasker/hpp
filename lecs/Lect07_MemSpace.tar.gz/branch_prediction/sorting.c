/**
 * Example of how the branch prediction capability can improve the code performance. Here we create an array of length N and compute the sum of all elements larger than 50.  Compare two versions: unsorted array (version 1) and partitioned array (version 2).
 * Compiler explorer link: https://godbolt.org/z/ll-VZJ
 *
 * Course: High Performance Programming, Uppsala University
 *
 * Author: Anastasia Kruchinina <anastasia.kruchinina@it.uu.se>
 * Inspired by https://stackoverflow.com/questions/11227809/why-is-it-faster-to-process-a-sorted-array-than-an-unsorted-array
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>


typedef double myType;

static double get_wall_seconds() {
        struct timeval tv;
        gettimeofday(&tv, NULL);
        double seconds = tv.tv_sec + (double)tv.tv_usec / 1000000;
        return seconds;
}

int main (int argc, const char **argv)
{
        if(argc != 3) {printf("%s N version\n", argv[0]);
                       printf("version: (1) unsorted array, (2) partitioned array\n");
                       return -1;}
        int N = atoi(argv[1]);
        int ver = atoi(argv[2]);
        srand(time(0));
        int i, j;
        myType sum;
        double time1;
        int n_repeat = 10000; // how many time to repeat the test

        // create an array and assign values between 1 and 99
        myType* a  = (myType*)malloc(N*sizeof(myType));

        if(ver == 1)
        {
                // unsorted array
                for(i = 0; i < N; i++)
                        a[i] = rand() % 100; // 0...99

        }else
        {
                // partition the array: first half contain elements lerger than 50, second half contain elements less than 50
                for(i = 0; i < N/2; i++)
                        a[i] = rand() % 50+50; // 50...99
                for(i = N/2; i < N; i++)
                        a[i] = rand() % 50; // 0...49
        }

        time1 = get_wall_seconds();
        for (int i = 0; i < n_repeat; ++i)
        {
                sum = 0;
                for (int j = 0; j < N; ++j)
                {
                        if (a[j] >= 50)
                                sum += a[j];
                }
        }
        printf("Tests took %7.3f wall seconds.\n", get_wall_seconds()-time1);
        printf("Sum: %lf\n", (double)sum);

        free(a);

        return 0;
}
