#define G 33

void print_pyramid(int pyramidSize);
