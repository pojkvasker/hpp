#include "functions.h"



float scalarproduct(float * array1, float * array2, size_t length) {

        float sum = 0.0f;
        for (size_t i = 0; i < length; ++i) {
                sum += array1[i] *array2[i];
        }
        return sum;
}




float scalarproduct_aligned(float * array1, float * array2, size_t length) {


      float *x =__builtin_assume_aligned(array1, 32);
    	float *y =__builtin_assume_aligned(array2, 32);

        float sum = 0.0f;
        for (size_t i = 0; i < length; ++i) {
                sum += x[i] * y[i];
        }
        return sum;
}




float sse_scalarproduct(float * array1, float * array2, size_t length) {
        __m128 vsum = _mm_setzero_ps(); // Return vector of float __m128 with all elements set to zero.
        size_t i = 0;
        for (; i + 3 < length; i += 4) {
                // Multiply packed single-precision (32-bit) floating-point elements in a and b, add the intermediate result to packed elements in c, and store the results in dst.
                vsum = _mm_fmadd_ps(_mm_loadu_ps(array1 + i),
                                    _mm_loadu_ps(array2 + i),vsum);
        }
        float buffer[4];
        _mm_storeu_ps(buffer,vsum);
        float sum = buffer[0] + buffer[1] +
                    buffer[2] + buffer[3];

        // compure leftovers (if length%4 !=0)
        for (; i < length; ++i) {
                sum += array1[i] * array2[i];
        }
        return sum;
}


float avx_scalarproduct(float * array1, float * array2, size_t length) {
        __m256 vsum = _mm256_setzero_ps(); // Return vector of float __m256 with all elements set to zero.
        size_t i = 0;
        for (; i + 7 < length; i += 8) {
                // Multiply packed single-precision (32-bit) floating-point elements in a and b, add the intermediate result to packed elements in c, and store the results in dst.
                vsum = _mm256_fmadd_ps(_mm256_loadu_ps(array1 + i),
                                       _mm256_loadu_ps(array2 + i),vsum);

        }
        float buffer[8];
        _mm256_storeu_ps(buffer,vsum);
        float sum = buffer[0] + buffer[1] +
                    buffer[2] + buffer[3] +
                    buffer[4] + buffer[5] +
                    buffer[6] + buffer[7];

        // compure leftovers (if length%8 !=0)
        for (; i < length; ++i) {
                sum += array1[i] * array2[i];
        }
        return sum;
}



float avx_scalarproduct_aligned(float * array1, float * array2, size_t length) {
        __m256 vsum = _mm256_setzero_ps(); // Return vector of float __m256 with all elements set to zero.
        size_t i = 0;
        for (; i + 7 < length; i += 8) {
                // Multiply packed single-precision (32-bit) floating-point elements in a and b, add the intermediate result to packed elements in c, and store the results in dst.
                vsum = _mm256_fmadd_ps(_mm256_load_ps(array1 + i),
                                       _mm256_load_ps(array2 + i),vsum);

        }
        float __attribute__((aligned (16))) buffer[8];
        _mm256_store_ps(buffer,vsum);
        float sum = buffer[0] + buffer[1] +
                    buffer[2] + buffer[3] +
                    buffer[4] + buffer[5] +
                    buffer[6] + buffer[7];

        // compure leftovers (if length%8 !=0)
        for (; i < length; ++i) {
                sum += array1[i] * array2[i];
        }
        return sum;
}
