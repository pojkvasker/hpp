#include <stdio.h>
#include <string.h>
#include <stdlib.h>


struct data {
    int m;      // 4 bytes
    double n;   // 8 bytes
    char x;     // 1 byte
    float f;    // 4 bytes
};//__attribute__ (( __packed__ ) );

int main() {

    FILE *fp;
    fp = fopen("./little_bin_file", "r");

    struct data d;
    printf("sizeof(data) = %lu\n", sizeof(d));

    fread(&d, sizeof(d), 1, fp);

    printf("%d\n", d.m);
    printf("%lf\n", d.n);
    printf("%c\n", d.x);
    printf("%f\n", d.f);

    fclose(fp);
    return 0;
}
