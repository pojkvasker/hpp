/**
 * Example of cache optimization using different loop order for
 * matrix-matrix multiplication.
 *
 * Course: High Performance Programming, Uppsala University
 *
 * Author: Ali Dorostkar <ali.dorostkar@it.uu.se>
 * Modified by: Elias Rudberg <elias.rudberg@it.uu.se>
 *
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <string.h>

static double get_wall_seconds() {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  double seconds = tv.tv_sec + (double)tv.tv_usec / 1000000;
  return seconds;
}

void fill_matrix(double *A, int N){
  int i,j;
  srand(time(NULL));
  for (i=0; i<N ; i++)
    for (j=0 ; j<N ; j++)
      A[i*N + j] = (double)rand()/RAND_MAX*20-10;
}

void mult_ijk(double *A,double *B,double *C, int n){
  int k,i,j;
  for(i = 0; i < n; i++) {
    for(j = 0; j < n; j++) {
      for(k = 0; k < n; k++) {
	C[i*n+j] = C[i*n+j] + A[i*n+k]*B[k*n+j];
      }
    }
  }
}

void mult_ikj(double *A,double *B,double *C, int n){
  int k,i,j;
  for(i = 0; i < n; i++) {
    for(k = 0; k < n; k++) {
      for(j = 0; j < n; j++) {
	C[i*n+j] = C[i*n+j] + A[i*n+k]*B[k*n+j];
      }
    }
  }
}

void mult_jik(double *A,double *B,double *C, int n){
  int k,i,j;
  for(j = 0; j < n; j++) {
    for(i = 0; i < n; i++) {
      for(k = 0; k < n; k++) {
	C[i*n+j] = C[i*n+j] + A[i*n+k]*B[k*n+j];
      }
    }
  }
}

void mult_jki(double *A,double *B,double *C, int n){
  int k,i,j;
  for(j = 0; j < n; j++) {
    for(k = 0; k < n; k++) {
      for(i = 0; i < n; i++) {
	C[i*n+j] = C[i*n+j] + A[i*n+k]*B[k*n+j];
      }
    }
  }
}

void mult_kij(double *A,double *B,double *C, int n){
  int k,i,j;
  for(k = 0; k < n; k++) {
    for(i = 0; i < n; i++) {
      for(j = 0; j < n; j++) {
	C[i*n+j] = C[i*n+j] + A[i*n+k]*B[k*n+j];
      }
    }
  }
}

void mult_kji(double *A,double *B,double *C, int n){
  int k,i,j;
  for(k = 0; k < n; k++) {
    for(j = 0; j < n; j++) {
      for(i = 0; i < n; i++) {
	C[i*n+j] = C[i*n+j] + A[i*n+k]*B[k*n+j];
      }
    }
  }
}

/* Use typedef to declare a function pointer type called
   functionPtrType for a function that takes arguments of the types
   (double*, double* ,double*, int). */
typedef void (*functionPtrType)(double*, double* ,double*, int);

void run_tests(functionPtrType f, const char* name, double* A, double* B, double* C, double* Cref, int n) {
  printf("%s:\n", name);
  double t_tot = 0;
  double maxabsdiff = 0;
  int nRepeats = 5;
  int rep, i;
  for(rep = 0; rep < nRepeats; rep++) {
    memset(C, 0, n*n*sizeof(double));
    double t = get_wall_seconds();
    f(A, B, C, n);
    t_tot += get_wall_seconds() - t;
    /* Done. Now compare the result to the given Cref matrix. */
    for(i = 0; i < n*n; i++) {
      double absdiff = fabs(C[i]-Cref[i]);
      if(absdiff > maxabsdiff)
	maxabsdiff = absdiff;
    }
  }
  double t_avg = t_tot / nRepeats;
  printf("==> Average time: %9.3f ms  (diff %g)\n", t_avg*1000, maxabsdiff);
}

int main (int argc , char *argv[]){
  int n;
  double *A, *B, *C, *D;

  if(argc != 2){
    printf("The program should have exactly one input argument!\n");
    return 1;
  }
  n = atoi(argv[1]);

  printf("Multiply Matrices of size %d-by-%d\n", n,n);

  A = (double *)malloc(n*n*sizeof(double));
  B = (double *)malloc(n*n*sizeof(double));
  C = (double *)calloc(n*n,sizeof(double));
  D = (double *)calloc(n*n,sizeof(double));
  fill_matrix(A, n);
  fill_matrix(B, n);

  /* First compute D that will be used as a reference. */
  mult_ijk(A, B, D, n);
  
  run_tests(mult_ijk, "mult_ijk", A, B, C, D, n);
  run_tests(mult_ikj, "mult_ikj", A, B, C, D, n);
  run_tests(mult_jik, "mult_jik", A, B, C, D, n);
  run_tests(mult_jki, "mult_jki", A, B, C, D, n);
  run_tests(mult_kij, "mult_kij", A, B, C, D, n);
  run_tests(mult_kji, "mult_kji", A, B, C, D, n);

  free(A);
  free(B);
  free(C);
  free(D);
  return 0;
}
