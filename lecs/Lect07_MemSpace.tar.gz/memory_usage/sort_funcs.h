void merge_sort (int* list, int N);
void merge_sort_nofree (int* list, int N);
void merge_sort_buffer (int* list, int* buffer, int N);
