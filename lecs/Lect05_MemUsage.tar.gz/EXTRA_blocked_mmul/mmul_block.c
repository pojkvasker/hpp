/**
 * Example of cache optimization using blocking in the
 * matrix-matrix multiplication.
 *
 * Course: High Performance Programming, Uppsala University
 *
 * Author: Anastasia Kruchinina
 *
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <string.h>
#include <assert.h>


#define max(a,b) (((a) (b)) ? (a) : (b))
#define min(a,b) (((a) < (b)) ? (a) : (b))


static double get_wall_seconds() {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  double seconds = tv.tv_sec + (double)tv.tv_usec / 1000000;
  return seconds;
}

void fill_matrix(double *A, int N){
  int i,j;
  srand(time(NULL));
  for (i=0; i<N ; i++)
    for (j=0 ; j<N ; j++)
      A[i*N + j] = (double)rand()/RAND_MAX*20-10;
}


/*
Standard matrix multiplication
*/
void mult_ikj(double *A,double *B,double *C, int n, int dummy_blocksize){
  int k,i,j;
  for(i = 0; i < n; i++) {
    for(k = 0; k < n; k++) {
      for(j = 0; j < n; j++) {
	C[i*n+j] = C[i*n+j] + A[i*n+k]*B[k*n+j];
      }
    }
  }
}


/*
Blocked matrix multiplication

Multiply submatrices of big matrices. No extra memory allocation is done. 
*/
void mult_ikj_block(double *A,double *B,double *C, int n, int blocksize){
  int k,i,j;
  int kb,ib,jb;
  int bs = blocksize;
 
  for(ib = 0; ib < n; ib+=bs) {
    for(kb = 0; kb < n; kb+=bs) {
      for(jb = 0; jb < n; jb+=bs) {

	  for(i = ib; i < min(ib+bs, n); i++) {
    	    for(k = kb; k < min(kb+bs, n); k++) {
      	      for(j = jb; j < min(jb+bs, n); j++) {
 		  C[i*n+j] = C[i*n+j] + A[i*n+k]*B[k*n+j];
		}
	    }	
	  }

      }
    }
  }
}


/*
Blocked matrix multiplication

Copy submatrices to the preallocated memory blocks, multiply these blocks
and copy computed data to the big matrix.
Allocate memory for submatrices statically or dynamically.

Note that due to the different summation order, due to the rounding errors
the result matrix may be slightly different (diff can be > 0).

*/
void mult_ikj_block_2(double *A,double *B,double *C, int n, int blocksize){
  int k,i,j, iStart, jStart, kStart;
  int bs = blocksize;

  int nBlocks = n / bs;

  // allocate submatrices statically
  double subMatA[bs*bs], subMatB[bs*bs], subMatC[bs*bs];

  // allocate submatrices dynamically (don't forget to free)
/*  double* subMatA = (double *)malloc(bs*bs*sizeof(double));
  double* subMatB = (double *)malloc(bs*bs*sizeof(double));
  double* subMatC = (double *)malloc(bs*bs*sizeof(double));*/

  if(n % bs != 0) {
    printf("Error: n not divisible by blocksize.\n");
    return;
  }
 
  for(int block_i = 0; block_i < nBlocks; block_i++) {
    for(int block_k = 0; block_k < nBlocks; block_k++) {
      for(int block_j = 0; block_j < nBlocks; block_j++) {

	 iStart = block_i*bs;
	 jStart = block_j*bs;
	 kStart = block_k*bs;

	//copy data
	      for(i = 0; i < bs; i++)
		for(k = 0; k < bs; k++)
		  subMatA[i*bs+k] = A[(iStart+i)*n+(kStart+k)];
	      for(k = 0; k < bs; k++)
		for(j = 0; j < bs; j++)
		  subMatB[k*bs+j] = B[(kStart+k)*n+(jStart+j)];
	      for(i = 0; i < bs; i++)
		for(j = 0; j < bs; j++)
		  subMatC[i*bs+j] = 0;


			// multiply
	  for(i = 0; i < bs; i++) {
    	    for(k = 0; k < bs; k++) {
      	      for(j = 0; j < bs; j++) {
 		  subMatC[i*bs+j] += subMatA[i*bs+k]*subMatB[k*bs+j];
		}
	    }	
	  }

	      for(i = 0; i < bs; i++)
		for(j = 0; j < bs; j++)
		  C[(iStart+i)*n+(jStart+j)] += subMatC[i*bs+j];


      }
    }
  }

 /* free(subMatA);
  free(subMatB);
  free(subMatC);*/
}




/* Use typedef to declare a function pointer type called
   functionPtrType for a function that takes arguments of the types
   (double*, double* ,double*, int). */
typedef void (*functionPtrType)(double*, double* ,double*, int, int);

void run_tests(functionPtrType f, const char* name, double* A, double* B, double* C, double* Cref, int n, int blocksize) {
  printf("%s:\n", name);
  double t_tot = 0;
  double maxabsdiff = 0;
  int nRepeats = 5;
  int rep, i;
  for(rep = 0; rep < nRepeats; rep++) {
    memset(C, 0, n*n*sizeof(double));
    double t = get_wall_seconds();
    f(A, B, C, n, blocksize);
    t_tot += get_wall_seconds() - t;
    /* Done. Now compare the result to the given Cref matrix. */
    for(i = 0; i < n*n; i++) {
      double absdiff = fabs(C[i]-Cref[i]);
      if(absdiff > maxabsdiff)
	maxabsdiff = absdiff;
    }
  }
  double t_avg = t_tot / nRepeats;
  assert(maxabsdiff < 1e-10);
  printf("==> Average time: %9.3f ms  (diff %g)\n", t_avg*1000, maxabsdiff);
}

int main (int argc , char *argv[]){
  int n, blocksize;
  double *A, *B, *C, *D;

  if(argc != 3){
    printf("The program should have two input arguments!\n");
    return 1;
  }
  n = atoi(argv[1]);
  blocksize = atoi(argv[2]);

  printf("Multiply Matrices of size %d-by-%d\n", n,n);
  printf("Blocksize is %d\n", blocksize);

  A = (double *)malloc(n*n*sizeof(double));
  B = (double *)malloc(n*n*sizeof(double));
  C = (double *)calloc(n*n,sizeof(double));
  D = (double *)calloc(n*n,sizeof(double));
  fill_matrix(A, n);
  fill_matrix(B, n);

  /* First compute D that will be used as a reference. */
  mult_ikj(A, B, D, n, 0);
  run_tests(mult_ikj, "mult_ikj", A, B, C, D, n, 0);
  run_tests(mult_ikj_block, "mult_ikj_block", A, B, C, D, n, blocksize);
  run_tests(mult_ikj_block_2, "mult_ikj_block_2", A, B, C, D, n, blocksize);

  free(A);
  free(B);
  free(C);
  free(D);
  return 0;
}
