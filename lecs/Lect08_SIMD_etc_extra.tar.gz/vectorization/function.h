#include <stddef.h>
#include <time.h>
#include <stdlib.h>

typedef double MyType;

void sum_arrays(MyType *a, MyType *b, MyType *c, int N);

/* MATRIX MULTIPLICATION */
#if 0
void fill_matrix(MyType *A, int N);
void mult_kij(MyType *A, MyType *B, MyType *C, int n);
#endif

/* STRING OPERATIONS */
#if 0
void lowercase1(char* p);
void lowercase2(char* p);
#endif
